﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace WikiParser1
{
    public class WikiPageDbAdapter
    {
        private MySqlCommand m_InsertPageCmd;
        private MySqlCommand m_SelectPageCmd;
        private MySqlCommand m_SelectPageRangeCmd;


        private MySqlConnection m_connection;

        private MySqlTransaction m_transaction;

        internal String StorePageToDatabase(WikiPage p)
        {
            String result = "";
            MySqlCommand cmd;
            if (m_InsertPageCmd == null)
            {
                String query = "INSERT INTO `pages` (`id`, `namespace`, `pageTitle`, `redirect`, `user`, `model`, `format`, `comment`, `text`) VALUES (@id, @ns, @pageTitle, @redir, @u, @mod, @form, @comment, @text);";
                cmd = new MySqlCommand(query, m_connection);
                //add parameters
                cmd.Parameters.Add("@id", MySqlDbType.Int64);
                cmd.Parameters.Add("@ns", MySqlDbType.VarChar);
                cmd.Parameters.Add("@pageTitle", MySqlDbType.VarChar);
                cmd.Parameters.Add("@redir", MySqlDbType.VarChar);
                cmd.Parameters.Add("@u", MySqlDbType.VarChar);
                cmd.Parameters.Add("@mod", MySqlDbType.VarChar);
                cmd.Parameters.Add("@form", MySqlDbType.VarChar);
                cmd.Parameters.Add("@comment", MySqlDbType.MediumText);
                cmd.Parameters.Add("@text", MySqlDbType.LongText);
                m_InsertPageCmd = cmd;
            }
            //execute commands
            try
            {
                cmd = m_InsertPageCmd;
                cmd.Parameters[0].Value = p.m_Id;
                cmd.Parameters[1].Value = p.m_Namespace;
                cmd.Parameters[2].Value = p.m_Title;
                cmd.Parameters[3].Value = p.m_RedirectTitle;
                cmd.Parameters[4].Value = p.m_UserName;
                cmd.Parameters[5].Value = p.m_Model;
                cmd.Parameters[6].Value = p.m_Format;
                cmd.Parameters[7].Value = p.m_Comment;
                cmd.Parameters[8].Value = p.m_Text;
                //execute
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }


            return result;
        }

        internal void Open(string databaseName)
        {
            MySqlConnectionStringBuilder csb = new MySqlConnectionStringBuilder();
            csb.Database = databaseName;
            csb.Password = "";
            csb.Server = "localhost";
            csb.UserID = "root";
            m_connection = new MySqlConnection(csb.ConnectionString);

            m_connection.Open();

            MySqlCommand cmd = new MySqlCommand("SET max_allowed_packet=4194304", m_connection);
            cmd.ExecuteNonQuery();
            cmd = null;
        }

        internal void Close()
        {
            m_connection.Close();
        }

        /// <summary>
        /// NT-Получить максимальный первичный ключ в таблице. Возвращает -1 при ошибке.
        /// </summary>
        public Int64 GetMaxOfPageId()
        {
            Int64 result = -1;
            MySqlCommand cmd = new MySqlCommand("SELECT MAX(`id`) FROM `pages` WHERE 1 ;", m_connection);
            cmd.CommandTimeout = 600;
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt64(0);
            }
            rdr.Close();
            return result;
        }

        /// <summary>
        /// NT-Получить страницу по ее названию
        /// </summary>
        /// <param name="pageTitle">Название страницы</param>
        /// <param name="withText">Загружать также текст страницы</param>
        public List<WikiPage> GetPageByTitle(string title, bool withText)
        {
            MySqlCommand cmd = m_SelectPageCmd;
            //create command
            if (cmd == null)
            {
                
                String query = "SELECT * FROM `pages` WHERE(`pageTitle` = @pageTitle);";
                cmd = new MySqlCommand(query, m_connection);
                cmd.CommandTimeout = 600;
                //add parameters
                cmd.Parameters.Add("@pageTitle", MySqlDbType.VarChar);

                m_SelectPageCmd = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = title;
            MySqlDataReader rdr = cmd.ExecuteReader();

            //читаем ридер, закрываем его и возвращаем результат.
            return ProcessWikiPageReader(rdr, withText);
        }

        /// <summary>
        /// NT-Получить список страниц для обработки
        /// </summary>
        /// <param name="start">Начальный идентификатор в выборке</param>
        /// <param name="count">Размер выборки, строк</param>
        /// <param name="withText">Загружать также текст страницы</param>
        public List<WikiPage> GetPages(Int64 start, int count, bool withText)
        {
            
            MySqlCommand cmd = m_SelectPageRangeCmd;
            //create command
            if (cmd == null)
            {
                String query = "SELECT * FROM `pages` WHERE((`id` >= @idfrom) AND (`id` < @idto));";
                cmd = new MySqlCommand(query, m_connection);
                cmd.CommandTimeout = 600;
                //add parameters
                cmd.Parameters.Add("@idfrom", MySqlDbType.Int64);
                cmd.Parameters.Add("@idto", MySqlDbType.Int64);
                m_SelectPageRangeCmd = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = start;
            cmd.Parameters[1].Value = start + count;
            MySqlDataReader rdr = cmd.ExecuteReader();

            //читаем ридер, закрываем его и возвращаем результат.
            return ProcessWikiPageReader(rdr, withText);
        }

        /// <summary>
        /// NT-собрать данные ридера в список страниц
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>
        private List<WikiPage> ProcessWikiPageReader(MySqlDataReader rdr, bool withText)
        {
            
            List<WikiPage> lwp = new List<WikiPage>();

            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    WikiPage p = new WikiPage();

                    p.m_Id = rdr.GetInt32(0);
                    p.m_Namespace = rdr.GetString(1);
                    p.m_Title = rdr.GetString(2);
                    p.m_RedirectTitle = rdr.GetString(3);
                    p.m_UserName = rdr.GetString(4);
                    p.m_Model = rdr.GetString(5);
                    p.m_Format = rdr.GetString(6);
                    p.m_Comment = rdr.GetString(7);
                    //если нужен также текст страницы, то и его получаем
                    if(withText)
                        p.m_Text = rdr.GetString(8);
                    
                    lwp.Add(p);
                }
            }
            //закрываем ридер
            rdr.Close();

            return lwp;
        }

    }
}
