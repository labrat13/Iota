﻿using System;
using System.Collections.Generic;
using System.Text;
using MySqliteDbLayer;
using System.Data.SQLite;

namespace FindSeqNextAsm2
{
    class Program
    {

        /// <summary>
        /// 
        /// </summary>        
        static SqliteDbAdapter m_databaseSrc;
        static SQLiteTransaction m_transactionSrc;

        static SqliteDbAdapter m_databaseDst;
        static SQLiteTransaction m_transactionDst;
        /// <summary>
        /// номер шага как число полей кода слова
        /// </summary>
        static int m_stepnumber;

        static List<Seq2Item> m_items;

        static int m_blocksize = 1024 * 1024;
        
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Сборка двух библиотек в одну");
                Console.WriteLine("Program stepnum dest src");
                m_stepnumber = Int32.Parse(args[0]);
                string inputbasename = args[2];
                string outputbasename = args[1];
                //open src database
                //init database layer
                Console.WriteLine("Открываем исходную БД");
                m_databaseSrc = new SqliteDbAdapter(SqliteDbAdapter.CreateConnection(inputbasename));
                ////init database layer
                m_databaseSrc.Open();
                //m_databaseDst = new SqliteDbAdapter(SqliteDbAdapter.CreateConnection(outputbasename));

                //get min rowid
                Int32 minId = m_databaseSrc.seqGetMinRowId();
                    //get max rowid
                Int32 maxId = m_databaseSrc.seqGetMaxRowId();
                m_databaseSrc.Close();
                m_databaseSrc = null;

                for (int cnt = minId; cnt < maxId; cnt += m_blocksize)
                {
                    Console.WriteLine("Block: " + cnt.ToString());
                    //open src database
                    m_databaseSrc = new SqliteDbAdapter(SqliteDbAdapter.CreateConnection(inputbasename));
                    m_databaseSrc.Open();
                    m_databaseSrc.ExecuteCommand("PRAGMA cache_size = 50000;");
                    //m_databaseSrc.ExecuteCommand("ANALYZE");

                    Console.WriteLine("Allocated memory " + GC.GetTotalMemory(false).ToString());
                    
                    //read blocksize records
                    m_items = m_databaseSrc.seqGetRows(m_stepnumber, cnt, cnt + m_blocksize);
                    m_databaseSrc.Close();
                    m_databaseSrc = null;

                    Console.WriteLine("Allocated memory " + GC.GetTotalMemory(false).ToString());
                    
                    //open dest database
                    m_databaseDst = new SqliteDbAdapter(SqliteDbAdapter.CreateConnection(outputbasename));
                    m_databaseDst.Open();
                    m_databaseDst.ExecuteCommand("PRAGMA cache_size = 400000;");
                    m_databaseDst.ExecuteCommand("ANALYZE");
                    m_transactionDst = m_databaseDst.BeginTransaction();
                    
                    Console.WriteLine("Writing to database");
                    Console.Write("0");
                    //update blocksize records
                    foreach (Seq2Item item in m_items)
                    {
                        //insert or update if exists
                        m_databaseDst.seqAddSequence(item.m_codes, item.m_count);
                        if ((item.m_id & 0xFF) == 0)
                        {
                            Console.CursorLeft = 0; //вернуть курсор на начало строки
                            Console.Write(item.m_id);
                        }
                    }
                    Console.WriteLine();

                    m_transactionDst.Commit();
                    m_databaseDst.Close();
                    m_databaseDst = null;

                    m_items.Clear();
                    GC.Collect();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().ToString() + ex.Message);
            }

            Console.WriteLine("Завершено");
            //Console.ReadLine();
            return; 
        }
    }
}
