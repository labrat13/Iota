﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Data.OleDb;
using System.Globalization;

namespace RadioBase
{
    /// <summary>
    /// Слой абстракции БД
    /// </summary>
    public class CDbLayer
    {
        #region *** Fields ***
        /// <summary>
        /// database connection string
        /// </summary>
        public static String ConnectionString;
        /// <summary>
        /// database connection
        /// </summary>
        private System.Data.OleDb.OleDbConnection m_connection;
        /// <summary>
        /// Transaction for current connection
        /// </summary>
        private OleDbTransaction m_transaction;
        /// <summary>
        /// Коллекция единиц измерения для предметов
        /// </summary>
        private UnitCollection m_units;

        /// <summary>
        /// Корневой контейнер системы, созданный из кода
        /// </summary>
        private CContainer m_rootContainer;
        /// <summary>
        /// Корневая категория системы, созданный из кода
        /// </summary>
        private CCategory m_rootCategory;

        //все объекты команд сбрасываются в нуль при отключении соединения с БД
        /// <summary>
        /// Команда без параметров, используемая во множестве функций
        /// </summary>
        private OleDbCommand m_cmdWithoutArguments;
        private OleDbCommand m_cmdGetCategoryIDByWebName;
        private OleDbCommand m_cmdInsertCategory;
        private OleDbCommand m_cmdUpdateCategory;
        private OleDbCommand m_cmdGetContainerIDByWebTitle;
        private OleDbCommand m_cmdInsertContainer;
        private OleDbCommand m_cmdUpdateContainer;
        private OleDbCommand m_cmdGetItemIDByWebTitle;
        private OleDbCommand m_cmdInsertItem;
        private OleDbCommand m_cmdUpdateItem;

        #endregion
        
        /// <summary>
        /// NT-Конструктор
        /// </summary>
        public CDbLayer()
        {
            //m_transaction = null;
        }
        
        #region *** Properties ***
        /// <summary>
        /// Получить коллекцию единиц измерения
        /// </summary>
        public UnitCollection QuantityUnits
        {
            get { return m_units; }
        }

        /// <summary>
        /// Получить корневую категорию
        /// </summary>
        public CCategory RootCategory
        {
            get { return m_rootCategory; }
        }

        /// <summary>
        /// Получить корневой контейнер
        /// </summary>
        public CContainer RootContainer
        {
            get { return m_rootContainer; }
        }
        #endregion

        /// <summary>
        /// NT-Создать и инициализировать объект БД
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static CDbLayer SetupDbLayer(String connectionString)
        {
            //теперь создать новый интерфейс БД
            CDbLayer dblayer = new CDbLayer();
            //connect to database
            dblayer.Connect(connectionString);
            //загрузить коллекцию единиц измерения количества предметов в память
            //до показа карточки предмета
            dblayer.UnitReloads();
            //инициализировать корневые элементы классификаций 
            //Установить картинку для корневого контейнера
            dblayer.initRootObjects(Properties.Resources.RootCategoryWebname, Properties.Resources.DefaultCategoryIcon, Properties.Resources.RootContainerWebname, Properties.Resources.NoPhoto, Properties.Resources.RootElementDescriptionText);

            return dblayer;
        }


        /// <summary>
        /// NT-Открыть соединение с БД
        /// </summary>
        /// <param name="connectionString">Строка соединения с БД</param>
        public void Connect(String connectionString)
        {
            //create connection
            OleDbConnection con = new OleDbConnection(connectionString);
            //try open connection
            con.Open();
            con.Close();
            //close existing connection
            Disconnect();
            //open new connection and set as primary
            this.m_connection = con;
            ConnectionString = connectionString;
            this.m_connection.Open();

            return;
        }


        /// <summary>
        /// NT-Закрыть соединение с БД
        /// </summary>
        public void Disconnect()
        {
            if (m_connection != null)
            {
                if (m_connection.State == System.Data.ConnectionState.Open)
                    m_connection.Close();
                m_connection = null;
            }
            
            //все объекты команд сбросить в нуль при отключении соединения с БД, чтобы ссылка на объект соединения при следующем подключении не оказалась устаревшей
            ClearCommands();

            return;
        }

        /// <summary>
        /// NT-все объекты команд сбросить в нуль
        /// </summary>
        private void ClearCommands()
        {
            m_cmdWithoutArguments = null;
            m_cmdGetCategoryIDByWebName = null;
            m_cmdInsertCategory = null;
            m_cmdUpdateCategory = null;
            m_cmdGetContainerIDByWebTitle = null;
            m_cmdInsertContainer = null;
            m_cmdUpdateContainer = null;
            m_cmdGetItemIDByWebTitle = null;
            m_cmdInsertItem = null;
            m_cmdUpdateItem = null;

            return;
        }

        /// <summary>
        /// NT-Начать транзакцию. 
        /// </summary>
        public void TransactionBegin()
        {
            m_transaction = m_connection.BeginTransaction();
            //сбросить в нуль все объекты команд, чтобы они были пересозданы для новой транзакции
            ClearCommands();
        }
        //NT-Подтвердить транзакцию Нужно закрыть соединение после этого!
        public void TransactionCommit()
        {
            m_transaction.Commit();
            //сбросить в нуль все объекты команд, чтобы они были пересозданы для новой транзакции
            ClearCommands();

        }
        //NT-Отменить транзакцию. Нужно закрыть соединение после этого!
        public void TransactionRollback()
        {
            m_transaction.Rollback();
            //сбросить в нуль все объекты команд, чтобы они были пересозданы для новой транзакции
            ClearCommands();
        }

        /// <summary>
        /// NT-Создать строку соединения с БД
        /// </summary>
        /// <param name="dbFile">Путь к файлу БД</param>
        public static string createConnectionString(string dbFile)
        {
            //Provider=Microsoft.Jet.OLEDB.4.0;Data Source="C:\Documents and Settings\salomatin\Мои документы\Visual Studio 2008\Projects\RadioBase\радиодетали.mdb"
            OleDbConnectionStringBuilder b = new OleDbConnectionStringBuilder();
            b.Provider = "Microsoft.Jet.OLEDB.4.0";
            b.DataSource = dbFile;
            //user id and password can specify here
            return b.ConnectionString;
        }

        #region *** Функции единиц измерения предметов ***
        /// <summary>
        /// NT-Перезагрузить коллекцию единиц измерения из БД
        /// </summary>
        public void UnitReloads()
        {
            //clear old collection if exists
            if (m_units != null)
            {
                m_units.Clear();
                m_units = null;
            }
            //Создать объект коллекции единиц измерения
            m_units = new UnitCollection();
            //Заполнить коллекцию из таблицы БД
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM Units;", m_connection);
            cmd.CommandTimeout = 60;
            //read results
            OleDbDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    UnitCollectionItem i = new UnitCollectionItem();
                    i.m_id = rdr.GetInt32(0); //предполагается ненужным в памяти
                    i.m_code = rdr.GetInt32(1);
                    i.m_text = rdr.GetString(2);
                    i.m_descr = rdr.GetString(3);
                    this.m_units.Add(i);
                }
            }
            rdr.Close();
            return;
        }
        /// <summary>
        /// NT-Удалить единицу измерения из БД и пересоздать список
        /// </summary>
        /// <param name="unitCode"></param>
        public void UnitRemove(int unitCode)
        {
            this.DeleteUnit(unitCode);
            UnitReloads();
            return;
        }
        /// <summary>
        /// NT-Добавить единицу измерения в БД и пересоздать список
        /// </summary>
        /// <param name="unit"></param>
        public void UnitAdd(UnitCollectionItem unit)
        {
            this.InsertUnit(unit);
            UnitReloads();
            return;
        }
        /// <summary>
        /// NT-Обновить свойства единицы измерения и пересоздать список
        /// </summary>
        /// <param name="unit"></param>
        public void UnitUpdate(UnitCollectionItem unit)
        {
            this.DeleteUnit(unit.m_code);
            this.InsertUnit(unit);
            UnitReloads();
            return;
        }

        /// <summary>
        /// NT-Вставить в таблицу новую единицу измерения
        /// </summary>
        /// <param name="unit">Объект единицы измерения</param>
        private int InsertUnit(UnitCollectionItem unit)
        {
            //Вставить в таблицу новую единицу измерения
            //create command
            String query = "INSERT INTO Units(code, title, descr) VALUES (?, ?, ?);";
            OleDbCommand cmd = new OleDbCommand(query, this.m_connection);
            cmd.CommandTimeout = 60;
            cmd.Parameters.Add("@code", OleDbType.Integer);
            cmd.Parameters.Add("@title", OleDbType.WChar);
            cmd.Parameters.Add("@descr", OleDbType.WChar);

            //execute command
            cmd.Parameters[0].Value = unit.m_code;
            cmd.Parameters[1].Value = unit.m_text;
            cmd.Parameters[2].Value = unit.m_descr;

            return cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// NT-Удалить из таблицы единицу измерения по ее коду
        /// </summary>
        /// <param name="unitCode"></param>
        private int DeleteUnit(int unitCode)
        {
            //Удалить из таблицы единицу измерения по ее коду
            String query = String.Format(CultureInfo.InvariantCulture, "DELETE * FROM Units WHERE(code = {0};", unitCode);
            OleDbCommand cmd = new OleDbCommand(query, this.m_connection);
            cmd.CommandTimeout = 60;
            return cmd.ExecuteNonQuery();
        }
        #endregion

        /// <summary>
        /// NT-Создать и инициализировать специальные корневые объекты классификаций
        /// </summary>
        /// <param name="categoryWebname"></param>
        /// <param name="categoryIcon"></param>
        /// <param name="containerWebname"></param>
        /// <param name="containerPicture"></param>
        public void initRootObjects(string categoryWebname, Image categoryIcon, string containerWebname, Image containerPicture, string description)
        {
            //root category object
            this.m_rootCategory = new CCategory();
            m_rootCategory.Deleted = false;
            m_rootCategory.Description = description;
            m_rootCategory.Picture = categoryIcon;
            m_rootCategory.ObjectId.ElementId = 0;
            m_rootCategory.ObjectId.ParentCategoryId = 0;
            m_rootCategory.LastChangeDate = DateTime.Now;
            m_rootCategory.Notes = String.Empty;
            m_rootCategory.Title = categoryWebname;
            m_rootCategory.WebTitle = categoryWebname;

            //root container object
            m_rootContainer = new CContainer();
            m_rootContainer.Deleted = false;
            m_rootContainer.Description = description;
            m_rootContainer.Picture = containerPicture;
            m_rootContainer.ObjectId.ElementId = 0;
            m_rootContainer.ObjectId.ParentContainerId = 0;
            m_rootContainer.LastChangeDate = DateTime.Now;
            m_rootContainer.Notes = String.Empty;
            m_rootContainer.Title = containerWebname;
            m_rootContainer.WebTitle = containerWebname;

            return;
        }

        /// <summary>
        /// NT-Создать картинку из записи БД
        /// </summary>
        /// <param name="rdr">ридер строки таблицы</param>
        /// <param name="index">номер столбца таблицы, с картинкой</param>
        /// <returns>Объект Image или null, если нет в БД картинки</returns>
        private static Image createImageFromReader(OleDbDataReader rdr, int index)
        {
            //надо обрабатывать NULL в столбце с картинкой - возвращать null вместо картинки
            //get size of data
            //проверить, что размер данных соответствует фактическому
            Int64 len = 0;
            len = rdr.GetBytes(index, 0, null, 0, 12345678);
            if (len == 0) return null;
            else
            {
                //create buffer and read bytes
                Byte[] buff = new Byte[len];
                rdr.GetBytes(index, 0, buff, 0, (Int32)len);
                //make image
                Image img = CImageProcessor.ImageFromBytes(buff);
                return img;
            }
        }

        /// <summary>
        /// NT-Проверить, что веб-имя присутствует в таблицах элементов 
        /// </summary>
        /// <param name="name">веб-имя</param>
        /// <returns>true  если имя уже присутствует, false в противном случае</returns>
        public bool IsDbContainsWebName(string name)
        {
            //использовать вызовы функций вроде
            //internal int getItemIDByWebName(string webname)
            //которые возвращают -1 если такого имени нет в соответствующей таблице

            //Это надо делать быстро
            //проверим имена корневых классификаторов
            if (String.Equals(this.m_rootCategory.WebTitle, name)) return true;
            if (String.Equals(this.m_rootContainer.WebTitle, name)) return true;

            Int32 result = 0;

            //просматриваем таблицу предметов
            result = getItemIdByWebName(name);
            if (result >= 0) return true;

            //просматриваем таблицу контейнеров
            result = getContainerIdByWebName(name);
            if (result >= 0) return true;

            //просматриваем таблицу категорий
            result = getCategoryIdByWebName(name);
            if (result >= 0) return true;

            //ничего не нашли
            return false;
        }

        #region *** Category functions ***
        /// <summary>
        /// NT-Получить идентификатор записи категории по его веб-идентификатору
        /// </summary>
        /// <param name="webtitle">веб-идентификатор категории</param>
        /// <returns>Идентификатор записи категории или -1 если нет такой записи</returns>
        public int getCategoryIdByWebName(string name)
        {
            //проверим корневой элемент
            if (String.Equals(this.m_rootCategory.WebTitle, name)) return 0;

            //SELECT id FROM Cats WHERE (shtitle = ?)
            //create command
            if (m_cmdGetCategoryIDByWebName == null)
            {
                m_cmdGetCategoryIDByWebName = new OleDbCommand("SELECT id FROM Cats WHERE (shtitle = ?);", this.m_connection, m_transaction);
                m_cmdGetCategoryIDByWebName.CommandTimeout = 60;
                m_cmdGetCategoryIDByWebName.Parameters.Add("@shtitle", OleDbType.WChar);
            }
            //execute command
            m_cmdGetCategoryIDByWebName.Parameters[0].Value = name;
            //read results
            OleDbDataReader rdr = m_cmdGetCategoryIDByWebName.ExecuteReader();
            int result = -1;
            if (rdr.HasRows)
            {
                rdr.Read(); //only first row
                result = rdr.GetInt32(0);
            }
            //close reader
            rdr.Close();
            return result;
        }
        /// <summary>
        /// NT-Получить объект категории по его числовому идентификатору
        /// </summary>
        /// <param name="catid">Идентификатор категории</param>
        /// <param name="readAll">True - загружать текст заметок, False - не загружать.</param>
        /// <returns>Объект категории или null</returns>
        internal CCategory getCategoryByTableId(int catid, bool readAll)
        {
            //проверим корневой элемент
            if (catid == this.m_rootCategory.ObjectId.ElementId) return this.m_rootCategory;

            //SELECT * FROM Cats WHERE (id = ?)
            //create command
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //execute command
            string query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Cats WHERE (id = {0});", catid);
            m_cmdWithoutArguments.CommandText = query;
            //read results
            OleDbDataReader rdr = m_cmdWithoutArguments.ExecuteReader();
            CCategory c = null;
            if (rdr.HasRows)
            {
                rdr.Read();
                c = ReadCategoryRow(rdr, readAll);
            }
            //close reader
            rdr.Close();
            return c;
        }
        /// <summary>
        /// NT-прочитать строку таблицы
        /// </summary>
        /// <param name="rdr">OleDbDataReader объект, готовый к чтению строки таблицы</param>
        /// <param name="readAll">True - загружать текст заметок, False - не загружать.</param>
        /// <returns>Объект категории</returns>
        private static CCategory ReadCategoryRow(OleDbDataReader rdr, bool readAll)
        {
            CCategory c = new CCategory();
            c.ObjectId.ElementId = rdr.GetInt32(0); //id
            c.Title = rdr.GetString(1);//title
            c.WebTitle = rdr.GetString(2);//shtitle
            c.Deleted = rdr.GetBoolean(3);//deleted
            //read icon here
            c.Picture = createImageFromReader(rdr, 4);//icon
            c.Description = rdr.GetString(5);//descr
            c.ObjectId.ParentCategoryId = rdr.GetInt32(6);//parent
            if (readAll == true)
            {
                c.Notes = rdr.GetString(7);//notes
            }
            return c;
        }
        /// <summary>
        /// NT-получить список категорий по идентификатору родительской категории
        /// </summary>
        /// <param name="parentId">Идентификатор родительской категории</param>
        /// <param name="readAll">True - загружать текст заметок, False - не загружать.</param>
        /// <returns></returns>
        public List<CCategory> getCategoriesByParentId(int parentId, bool readAll)
        {
            //SELECT * FROM Cats WHERE (parent = ?)
            //create command
            if (m_cmdWithoutArguments == null) //эта команда также используется в другой функции
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //execute command
            string query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Cats WHERE (parent = {0});", parentId);
            m_cmdWithoutArguments.CommandText = query;
            //read results
            OleDbDataReader rdr = m_cmdWithoutArguments.ExecuteReader();
            List<CCategory> li = new List<CCategory>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    CCategory c = ReadCategoryRow(rdr, readAll);
                    li.Add(c);
                }
            }
            //close reader
            rdr.Close();
            return li;
        }
        /// <summary>
        /// NT-быстро получить количество дочерних категорий по идентификатору родительской категории
        /// </summary>
        /// <param name="parentId">Идентификатор родительской категории</param>
        /// <returns>Возвращает число дочерних категорий или 0, если дочерних категорий нет</returns>
        private int getCountOfChildCategories(int parentId)
        {
            //"SELECT COUNT(id) FROM Cats WHERE (parent = ?);";
            //result = (Int32)cmd.ExecuteScalar(); //Тут могут быть исключения из-за другого типа данных
            //create command
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //execute command
            string query = String.Format(CultureInfo.InvariantCulture, "SELECT COUNT(id) FROM Cats WHERE (parent = {0});", parentId);
            m_cmdWithoutArguments.CommandText = query;
            int result = (Int32)m_cmdWithoutArguments.ExecuteScalar(); //Тут могут быть исключения из-за другого типа данных

            return result;
        }
        /// <summary>
        /// NT-Вставить в таблицу категорий новую категорию
        /// </summary>
        /// <param name="c">Объект новой категории</param>
        /// <returns>Возвращает число задействованных строк таблицы</returns>
        private int insertCategory(CCategory c)
        {
            String query = "INSERT INTO Cats(title, shtitle, deleted, icon, descr, parent, notes) VALUES (?, ?, ?, ?, ?, ?, ?);";
            OleDbCommand cmd = this.m_cmdInsertCategory;
            //create command
            if (cmd == null)
            {
                cmd = new OleDbCommand(query, this.m_connection, m_transaction);
                cmd.CommandTimeout = 60;
                cmd.Parameters.Add("@title", OleDbType.WChar);
                cmd.Parameters.Add("@shtitle", OleDbType.WChar);
                cmd.Parameters.Add("@deleted", OleDbType.Boolean);
                cmd.Parameters.Add("@icon", OleDbType.Binary);
                cmd.Parameters.Add("@descr", OleDbType.WChar);
                cmd.Parameters.Add("@parent", OleDbType.Integer);
                cmd.Parameters.Add("@notes", OleDbType.WChar);
                //store back
                this.m_cmdInsertCategory = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = c.Title;
            cmd.Parameters[1].Value = c.WebTitle;
            cmd.Parameters[2].Value = c.Deleted;
            cmd.Parameters[3].Value = CImageProcessor.ImageToBytes(c.Picture);
            cmd.Parameters[4].Value = c.Description;
            cmd.Parameters[5].Value = c.ObjectId.ParentCategoryId;
            cmd.Parameters[6].Value = c.Notes;
            int result = cmd.ExecuteNonQuery();
            //записать идентификатор записи в объект категории
            //иначе он будет вставляться снова при каждом обновлении
            c.ObjectId.ElementId = this.getCategoryIdByWebName(c.WebTitle);
            return result;
        }
        /// <summary>
        /// NT-Обновить данные категории 
        /// </summary>
        /// <param name="c">Объект обновляемой категории</param>
        /// <returns>Возвращает число задействованных строк таблицы</returns>
        private int updateCategory(CCategory c)
        {
            //сделать функцию для обновления записи категории
            String query = "UPDATE Cats SET title=?, shtitle=?, deleted=?, icon=?, descr=?, parent=?, notes=? WHERE (Cats.id = ?)";
            OleDbCommand cmd = this.m_cmdUpdateCategory;
            //create command
            if (cmd == null)
            {
                cmd = new OleDbCommand(query, this.m_connection, m_transaction);
                cmd.CommandTimeout = 60;
                cmd.Parameters.Add("@title", OleDbType.WChar);
                cmd.Parameters.Add("@shtitle", OleDbType.WChar);
                cmd.Parameters.Add("@deleted", OleDbType.Boolean);
                cmd.Parameters.Add("@icon", OleDbType.Binary);
                cmd.Parameters.Add("@descr", OleDbType.WChar);
                cmd.Parameters.Add("@parent", OleDbType.Integer);
                cmd.Parameters.Add("@notes", OleDbType.WChar);
                cmd.Parameters.Add("@id", OleDbType.Integer);
                //store back
                this.m_cmdUpdateCategory = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = c.Title;
            cmd.Parameters[1].Value = c.WebTitle;
            cmd.Parameters[2].Value = c.Deleted;
            cmd.Parameters[3].Value = CImageProcessor.ImageToBytes(c.Picture);
            cmd.Parameters[4].Value = c.Description;
            cmd.Parameters[5].Value = c.ObjectId.ParentCategoryId;
            cmd.Parameters[6].Value = c.Notes;
            cmd.Parameters[7].Value = c.ObjectId.ElementId;
            int result = cmd.ExecuteNonQuery();
            return result;
        }

        #endregion
        
        #region *** Container functions ***
        /// <summary>
        /// NT-Получить ID контейнера по его веб-имени
        /// </summary>
        /// <param name="webname">веб-имя</param>
        /// <returns>ID контейнера или -1 если не найден</returns>
        public int getContainerIdByWebName(string name)
        {
            //проверим корневой элемент
            if (String.Equals(this.m_rootContainer.WebTitle, name)) return 0;

            //SELECT id FROM Conts WHERE (shtitle = ?)
            //create command
            if (m_cmdGetContainerIDByWebTitle == null)
            {
                m_cmdGetContainerIDByWebTitle = new OleDbCommand("SELECT id FROM Conts WHERE (shtitle = ?);", this.m_connection, m_transaction);
                m_cmdGetContainerIDByWebTitle.CommandTimeout = 60;
                m_cmdGetContainerIDByWebTitle.Parameters.Add("@shtitle", OleDbType.WChar);
            }
            //execute command
            m_cmdGetContainerIDByWebTitle.Parameters[0].Value = name;
            //read results
            OleDbDataReader rdr = m_cmdGetContainerIDByWebTitle.ExecuteReader();
            int result = -1;
            if (rdr.HasRows)
            {
                rdr.Read(); //only first row
                result = rdr.GetInt32(0);
            }
            //close reader
            rdr.Close();
            return result;
        }
        /// <summary>
        /// NT-Получить объект контейнера по его первичному ключу
        /// </summary>
        /// <param name="id">Table primary key</param>
        /// <param name="readAll">True - загружать изображения и текст заметок, False - не загружать.</param>
        /// <returns>объект контейнера или null</returns>
        public CContainer getContainerByTableId(int id, bool readAll)
        {
            //проверим корневой элемент
            if (id == this.m_rootContainer.ObjectId.ElementId) return this.m_rootContainer;

            //SELECT * FROM Conts WHERE (id = ?)
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //create command
            string query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Conts WHERE (id = {0});", id);
            m_cmdWithoutArguments.CommandText = query;
            //execute command
            //read single row results
            OleDbDataReader rdr = m_cmdWithoutArguments.ExecuteReader();
            CContainer c = null;
            if (rdr.HasRows)
            {
                rdr.Read(); //only first row
                c = ReadContainerRow(rdr, readAll);
            }
            //close reader
            rdr.Close();
            return c;
        }
        /// <summary>
        /// NT-Прочитать строку таблицы
        /// </summary>
        /// <param name="rdr">Ридер, готовый к чтению строки таблицы</param>
        /// <param name="readAll">True - загружать изображения и текст заметок, False - не загружать.</param>
        /// <returns>Объект контейнера, содержащий данные из строки таблицы</returns>
        private static CContainer ReadContainerRow(OleDbDataReader rdr, bool readAll)
        {
            CContainer c = new CContainer();
            c.ObjectId.ElementId = rdr.GetInt32(0); //id
            c.Title = rdr.GetString(1);//title
            c.WebTitle = rdr.GetString(2);//shtitle
            c.Deleted = rdr.GetBoolean(3);//deleted
            //read icon here
            if (readAll == true) c.Picture = createImageFromReader(rdr, 4);//icon
            c.Description = rdr.GetString(5);//descr
            c.LastChangeDate = rdr.GetDateTime(6);//invdate
            c.ObjectId.ParentContainerId = rdr.GetInt32(7);//parent
            if (readAll == true) c.Notes = rdr.GetString(8);//notes
            
            return c;
        }
        /// <summary>
        /// NT-получить список элементов по идентификатору родительского элемента
        /// </summary>
        /// <param name="parentId">Идентификатор родительского контейнера</param>
        /// <param name="readAll">True - загружать изображения и текст заметок, False - не загружать.</param>
        /// <returns></returns>
        public List<CContainer> getContainersByParentId(int parentId, bool readAll)
        {
            //тут не проверяем корневые элементы, так как их невозможно запросить или получить здесь.

            //create command
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }

            string query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Conts WHERE (parent = {0});", parentId);
            m_cmdWithoutArguments.CommandText = query;
            
            //execute command
            //read single row results
            OleDbDataReader rdr = m_cmdWithoutArguments.ExecuteReader();
            List<CContainer> li = new List<CContainer>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    CContainer c = ReadContainerRow(rdr, readAll);
                    li.Add(c);
                }
            }
            //close reader
            rdr.Close();
            return li;
        }
        /// <summary>
        /// NT-быстро получить количество дочерних контейнеров по идентификатору родительского контейнера
        /// </summary>
        /// <param name="parentId">Идентификатор родительского контейнера</param>
        /// <returns></returns>
        private int getCountOfChildContainers(int parentId)
        {
            //"SELECT COUNT(id) FROM Conts WHERE (parent = ?);";
            //create command
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //execute command
            string query = String.Format(CultureInfo.InvariantCulture, "SELECT COUNT(id) FROM Conts WHERE (parent = {0});", parentId);
            m_cmdWithoutArguments.CommandText = query;
            int result = (Int32)m_cmdWithoutArguments.ExecuteScalar(); //Тут могут быть исключения из-за другого типа данных

            return result;
        }
        /// <summary>
        /// NT-Вставить в таблицу контейнеров новый контейнер
        /// </summary>
        /// <param name="c">Объект нового контейнера</param>
        private int insertContainer(CContainer c)
        {
            String query = "INSERT INTO Conts(title, shtitle, deleted, icon, descr, invdate, parent, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
            OleDbCommand cmd = this.m_cmdInsertContainer;
            //create command
            if (cmd == null)
            {
                cmd = new OleDbCommand(query, this.m_connection, m_transaction);
                cmd.CommandTimeout = 60;
                cmd.Parameters.Add("@title", OleDbType.WChar);
                cmd.Parameters.Add("@shtitle", OleDbType.WChar);
                cmd.Parameters.Add("@deleted", OleDbType.Boolean);
                cmd.Parameters.Add("@icon", OleDbType.Binary);
                cmd.Parameters.Add("@descr", OleDbType.WChar);
                cmd.Parameters.Add("@invdate", OleDbType.Date);
                cmd.Parameters.Add("@parent", OleDbType.Integer);
                cmd.Parameters.Add("@notes", OleDbType.WChar);
                //store back
                this.m_cmdInsertContainer = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = c.Title;
            cmd.Parameters[1].Value = c.WebTitle;
            cmd.Parameters[2].Value = c.Deleted;
            cmd.Parameters[3].Value = CImageProcessor.ImageToBytes(c.Picture);
            cmd.Parameters[4].Value = c.Description;
            cmd.Parameters[5].Value = c.LastChangeDate;
            cmd.Parameters[6].Value = c.ObjectId.ParentContainerId;
            cmd.Parameters[7].Value = c.Notes;
            int result = cmd.ExecuteNonQuery();
            //надо вписать как-то в объект контейнера первичный ключ таблицы - иначе при следующей записи он снова вставится в таблицу как новый
            //или перезагружать вид и элемент после сохранения, это выглядит запутанным клубком и можно вообще запутаться, что и когда происходит
            c.ObjectId.ElementId = this.getContainerIdByWebName(c.WebTitle);

            return result;
        }
        /// <summary>
        /// NT-Обновить запись контейнера
        /// </summary>
        /// <param name="cContainer"></param>
        private int updateContainer(CContainer c)
        {
            String query = "UPDATE Conts SET title=?, shtitle=?, deleted=?, icon=?, descr=?, invdate=?, parent=?, notes=? WHERE (id = ?);";
            OleDbCommand cmd = this.m_cmdUpdateContainer;
            //create command
            if (cmd == null)
            {
                cmd = new OleDbCommand(query, this.m_connection, m_transaction);
                cmd.CommandTimeout = 60;
                cmd.Parameters.Add("@title", OleDbType.WChar);
                cmd.Parameters.Add("@shtitle", OleDbType.WChar);
                cmd.Parameters.Add("@deleted", OleDbType.Boolean);
                cmd.Parameters.Add("@icon", OleDbType.Binary);
                cmd.Parameters.Add("@descr", OleDbType.WChar);
                cmd.Parameters.Add("@invdate", OleDbType.Date);
                cmd.Parameters.Add("@parent", OleDbType.Integer);
                cmd.Parameters.Add("@notes", OleDbType.WChar);
                cmd.Parameters.Add("@id", OleDbType.Integer);
                //store back
                this.m_cmdUpdateContainer = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = c.Title;
            cmd.Parameters[1].Value = c.WebTitle;
            cmd.Parameters[2].Value = c.Deleted;
            cmd.Parameters[3].Value = CImageProcessor.ImageToBytes(c.Picture);
            cmd.Parameters[4].Value = c.Description;
            cmd.Parameters[5].Value = c.LastChangeDate;
            cmd.Parameters[6].Value = c.ObjectId.ParentContainerId;
            cmd.Parameters[7].Value = c.Notes;
            cmd.Parameters[8].Value = c.ObjectId.ElementId;
            //execute command
            int result = cmd.ExecuteNonQuery();

            return result;
        }
        
        #endregion
        
        #region *** item functions ***
        /// <summary>
        /// NT-Получить идентификатор записи итема по веб-имени
        /// </summary>
        /// <param name="name">веб-имя элемента</param>
        /// <returns>Идентификатор записи элемента или -1 если не найден</returns>
        private int getItemIdByWebName(string name)
        {
            //SELECT id FROM Items WHERE (shtitle = ?)
            //create command
            if (m_cmdGetItemIDByWebTitle == null)
            {
                m_cmdGetItemIDByWebTitle = new OleDbCommand("SELECT id FROM Items WHERE (shtitle = ?);", this.m_connection, m_transaction);
                m_cmdGetItemIDByWebTitle.CommandTimeout = 60;
                m_cmdGetItemIDByWebTitle.Parameters.Add("@shtitle", OleDbType.WChar);
            }
            //execute command
            m_cmdGetItemIDByWebTitle.Parameters[0].Value = name;
            //read results
            OleDbDataReader rdr = m_cmdGetItemIDByWebTitle.ExecuteReader();
            int result = -1;
            if (rdr.HasRows)
            {
                rdr.Read(); //only first row
                result = rdr.GetInt32(0);
            }
            //close reader
            rdr.Close();

            return result;
        }
        /// <summary>
        /// NT-Получить объект предмета по его первичному ключу
        /// </summary>
        /// <param name="id">Table primary key</param>
        /// <param name="readAll">True - загружать изображения и текст заметок, False - не загружать.</param>
        /// <returns>объект предмета или null</returns>
        public CItem getItemByTableId(int id, bool readAll)
        {

            //SELECT * FROM Items WHERE (id = ?)
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //create command
            string query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Items WHERE (id = {0});", id);
            m_cmdWithoutArguments.CommandText = query;
            //execute command
            //read single row results
            OleDbDataReader rdr = m_cmdWithoutArguments.ExecuteReader();
            CItem c = null;
            if (rdr.HasRows)
            {
                rdr.Read(); //only first row
                c = ReadItemRow(rdr, readAll);
            }
            //close reader
            rdr.Close();
            return c;
        }
        /// <summary>
        /// NT-Прочитать данные элемента
        /// </summary>
        /// <param name="rdr">Ридер с данными</param>
        /// <param name="readAll">True - загружать изображения и текст заметок, False - не загружать.</param>
        /// <returns></returns>
        private static CItem ReadItemRow(OleDbDataReader rdr, bool readAll)
        {
            CItem c = new CItem();
            c.ObjectId.ElementId = rdr.GetInt32(0);//id
            c.Title = rdr.GetString(1);//title
            c.WebTitle = rdr.GetString(2);//shtitle
            c.Deleted = rdr.GetBoolean(3);//deleted
            //read icon here
            if (readAll) c.Picture = createImageFromReader(rdr, 4);//icon
            c.Description = rdr.GetString(5);//descr
            c.ObjectId.ParentCategoryId = rdr.GetInt32(6); //category
            c.ObjectId.ParentContainerId = rdr.GetInt32(7); //container
            c.Quantity = rdr.GetDouble(8);//num
            c.UnitCode = rdr.GetInt32(9);//unit
            c.LastChangeDate = rdr.GetDateTime(10);//creadate
            if (readAll) c.Notes = rdr.GetString(11);//notes

            return c;
        }
        /// <summary>
        /// NT-получить список элементов по идентификатору родительского элемента
        /// </summary>
        /// <param name="parentCategoryId">Идентификатор родительской категории, -1 если не нужен</param>
        /// <param name="parentContainerId">Идентификатор родительского контейнера, -1 если не нужен</param>
        /// <param name="readAll">True - загружать изображения и текст заметок, False - не загружать.</param>
        /// <returns></returns>
        public List<CItem> getItemsByParentId(int parentCategoryId, int parentContainerId, bool readAll)
        {
            //SELECT * FROM Items WHERE ((category = ?) AND (container = ?))
            //create command

            //выбрать строку запроса
            String query = null;
            //создаем композитный индекс для свитча
            int tmp = 0;
            if (parentCategoryId != -1) tmp = 2;
            if (parentContainerId != -1) tmp = tmp + 1;
            switch (tmp)
            {
                case 1: //container id specified
                    query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Items WHERE (container = {0});", parentContainerId);
                    break;

                case 2: //category id specified
                    query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Items WHERE (category = {0});", parentCategoryId);
                    break;

                case 3: //both id's specified
                    query = String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Items WHERE ((category = {0}) AND (container = {1}));", parentCategoryId, parentContainerId);
                    break;

                case 0://no id's specified
                default:
                    throw new Exception("Неверный аргумент: Один или несколько аргументов неверны");
            }
            //make command
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //execute command
            //read rows
            m_cmdWithoutArguments.CommandText = query;
            OleDbDataReader rdr = m_cmdWithoutArguments.ExecuteReader();
            List<CItem> li = new List<CItem>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    CItem c = ReadItemRow(rdr, readAll);
                    li.Add(c);
                }
            }
            //close reader
            rdr.Close();
            return li;
        }

        /// <summary>
        /// NT-Получить число элементов по идентификатору родительского элемента
        /// </summary>
        /// <param name="parentCategoryId">Идентификатор родительской категории, -1 если не нужен</param>
        /// <param name="parentContainerId">Идентификатор родительского контейнера, -1 если не нужен</param>
        /// <returns>Возвращает количество найденных элементов</returns>
        private int getCountOfItemsByParentId(int parentCategoryId, int parentContainerId)
        {
            //выбрать строку запроса
            String query = null;
            //создаем композитный индекс для свитча
            int tmp = 0;
            if (parentCategoryId != -1) tmp = 2;
            if (parentContainerId != -1) tmp = tmp + 1;
            switch (tmp)
            {
                case 1: //container id specified
                    query = String.Format(CultureInfo.InvariantCulture, "SELECT COUNT(id) FROM Items WHERE (container = {0});", parentContainerId);
                    break;

                case 2: //category id specified
                    query = String.Format(CultureInfo.InvariantCulture, "SELECT COUNT(id) FROM Items WHERE (category = {0});", parentCategoryId);
                    break;

                case 3: //both id's specified
                    query = String.Format(CultureInfo.InvariantCulture, "SELECT COUNT(id) FROM Items WHERE ((category = {0}) AND (container = {1}));", parentCategoryId, parentContainerId);
                    break;

                case 0://no id's specified
                    //TODO: при создании нового элемента и смене родительской категории в его карточке, мы оказываемся тут с -1 в обоих аргументах
                default:
                    throw new Exception("Неверный аргумент: Один или несколько аргументов неверны");
            }
            //make command
            if (m_cmdWithoutArguments == null)
            {
                m_cmdWithoutArguments = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
                m_cmdWithoutArguments.CommandTimeout = 60;
            }
            //execute command
            //read rows
            m_cmdWithoutArguments.CommandText = query;
            int result = (Int32)m_cmdWithoutArguments.ExecuteScalar(); //Тут могут быть исключения из-за другого типа данных
            
            return result;
        }

        /// <summary>
        /// NT-Вставить предмет в таблицу
        /// </summary>
        /// <param name="cItem">Объект предмета</param>
        private int insertItem(CItem c)
        {
            //Вставить предмет в таблицу и вписать в объект идентификатор первичного ключа
            String query = "INSERT INTO Items(title, shtitle, deleted, icon, descr, category, [container], num, unit, creadate, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            OleDbCommand cmd = this.m_cmdInsertItem;
            //create command
            if (cmd == null)
            {
                cmd = new OleDbCommand(query, this.m_connection, m_transaction);
                cmd.CommandTimeout = 60;
                
                cmd.Parameters.Add("@title", OleDbType.WChar);
                cmd.Parameters.Add("@shtitle", OleDbType.WChar);
                cmd.Parameters.Add("@deleted", OleDbType.Boolean);
                cmd.Parameters.Add("@icon", OleDbType.Binary);
                cmd.Parameters.Add("@descr", OleDbType.WChar);
                cmd.Parameters.Add("@category", OleDbType.Integer);
                cmd.Parameters.Add("@container", OleDbType.Integer);
                cmd.Parameters.Add("@num", OleDbType.Double);
                cmd.Parameters.Add("@unit", OleDbType.Integer);
                cmd.Parameters.Add("@creadate", OleDbType.Date);
                cmd.Parameters.Add("@notes", OleDbType.WChar);
                //store back
                this.m_cmdInsertItem = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = c.Title;
            cmd.Parameters[1].Value = c.WebTitle;
            cmd.Parameters[2].Value = c.Deleted;
            cmd.Parameters[3].Value = CImageProcessor.ImageToBytes(c.Picture);
            cmd.Parameters[4].Value = c.Description;
            cmd.Parameters[5].Value = c.ObjectId.ParentCategoryId;
            cmd.Parameters[6].Value = c.ObjectId.ParentContainerId;
            cmd.Parameters[7].Value = c.Quantity;
            cmd.Parameters[8].Value = c.UnitCode;
            cmd.Parameters[9].Value = c.LastChangeDate;
            cmd.Parameters[10].Value = c.Notes;
            int result = cmd.ExecuteNonQuery();
            //записать идентификатор записи в объект 
            //иначе он будет вставляться снова при каждом обновлении
            c.ObjectId.ElementId = this.getItemIdByWebName(c.WebTitle);

            return result;
        }
        /// <summary>
        /// NT-Вставить предмет в таблицу
        /// </summary>
        /// <param name="cItem">Объект предмета</param>
        private int updateItem(CItem c)
        {
            //Обновить запись предмета в таблице
            //Вставить предмет в таблицу и вписать в объект идентификатор первичного ключа
            String query = "UPDATE Items SET title=?, shtitle=?, deleted=?, icon=?, descr=?, category=?, [container]=?, num=?, unit=?, creadate=?, notes=? WHERE (id = ?)";
            OleDbCommand cmd = this.m_cmdUpdateItem;
            //create command
            if (cmd == null)
            {
                cmd = new OleDbCommand(query, this.m_connection, m_transaction);
                cmd.CommandTimeout = 60;

                cmd.Parameters.Add("@title", OleDbType.WChar);
                cmd.Parameters.Add("@shtitle", OleDbType.WChar);
                cmd.Parameters.Add("@deleted", OleDbType.Boolean);
                cmd.Parameters.Add("@icon", OleDbType.Binary);
                cmd.Parameters.Add("@descr", OleDbType.WChar);
                cmd.Parameters.Add("@category", OleDbType.Integer);
                cmd.Parameters.Add("@container", OleDbType.Integer);
                cmd.Parameters.Add("@num", OleDbType.Double);
                cmd.Parameters.Add("@unit", OleDbType.Integer);
                cmd.Parameters.Add("@creadate", OleDbType.Date);
                cmd.Parameters.Add("@notes", OleDbType.WChar);
                cmd.Parameters.Add("@id", OleDbType.Integer);
                //store back
                this.m_cmdUpdateItem = cmd;
            }
            //execute command
            cmd.Parameters[0].Value = c.Title;
            cmd.Parameters[1].Value = c.WebTitle;
            cmd.Parameters[2].Value = c.Deleted;
            cmd.Parameters[3].Value = CImageProcessor.ImageToBytes(c.Picture);
            cmd.Parameters[4].Value = c.Description;
            cmd.Parameters[5].Value = c.ObjectId.ParentCategoryId;
            cmd.Parameters[6].Value = c.ObjectId.ParentContainerId;
            cmd.Parameters[7].Value = c.Quantity;
            cmd.Parameters[8].Value = c.UnitCode;
            cmd.Parameters[9].Value = c.LastChangeDate;
            cmd.Parameters[10].Value = c.Notes;
            cmd.Parameters[11].Value = c.ObjectId.ElementId;
            int result = cmd.ExecuteNonQuery();

            return result;
        }
        
        #endregion

        #region *** Combine functions ***
        /// <summary>
        /// NT-Обновить данные элемента в таблице или создать новую запись
        /// </summary>
        /// <param name="elem">Сохраняемый элемент</param>
        public void StoreElement(CDbObject elem)
        {
            //У нового элемента id = 0, у существующего это первичный ключ таблицы
            //Сначала надо определить тип элемента, потом выбрать подходящую функцию 
            DbObjectTypes ty = CDbObject.getElementType(elem);

            //если идентификатор таблицы = 0, это новый объект или корневые объекты
            //если это корневые объекты, выходим - их не пишем в таблицы 
            if ((elem.ObjectId.ElementId == 0) && ((elem == m_rootCategory) || (elem == m_rootContainer)))
                return;
            //иначе это новый объект
            if (elem.ObjectId.IsInvalidIdentifier())
            {
                //если это новый объект, вставляем
                switch (ty)
                {
                    case DbObjectTypes.Category:
                        this.insertCategory((CCategory)elem);
                        break;
                    case DbObjectTypes.Container:
                        this.insertContainer((CContainer)elem);
                        break;
                    case DbObjectTypes.Item:
                        this.insertItem((CItem)elem);
                        break;
                    default:
                        break;
                }
            }
            else
            {
                //если это старый объект - обновляем
                switch (ty)
                {
                    case DbObjectTypes.Category:
                        this.updateCategory((CCategory)elem);
                        break;
                    case DbObjectTypes.Container:
                        this.updateContainer((CContainer)elem);
                        break;
                    case DbObjectTypes.Item:
                        this.updateItem((CItem)elem);
                        break;
                    default:
                        break;
                }
            }

            return;
        }

        /// <summary>
        /// NT-Получить объект элемента из БД по его веб-имени
        /// </summary>
        /// <param name="webname">веб-имя элемента</param>
        /// <returns>Объект элемента или null</returns>
        public CDbObject LoadElement(string webname)
        {
            //Получить объект элемента из БД по его веб-имени
            //если веб-имя пустое, вернуть нуль
            if (String.IsNullOrEmpty(webname)) return null;

            //тут надо поискать по каждой таблице и вернуть первый же результат, упаковав в подходящий объект
            //ищем в порядке частоты запросов: предметы, контейнеры, категории
            int id = this.getItemIdByWebName(webname);
            if (id >= 0)
            {
                CItem item = this.getItemByTableId(id, true);
                return item;
            }
            
            id = this.getContainerIdByWebName(webname);
            if (id >= 0)
            {
                CContainer con = this.getContainerByTableId(id, true);
                return con;
            }

            id = this.getCategoryIdByWebName(webname);
            if (id >= 0)
            {
                CCategory cat = this.getCategoryByTableId(id, true);
                return cat;
            }

            //return null as nothing found
            return null;
        }

        /// <summary>
        /// NT-Загрузить элемент по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <param name="readAll"></param>
        /// <returns></returns>
        public CDbObject LoadElement(CDbObjectId id, bool readAll)
        {
            CDbObject result = null;
            switch (id.ElementType)
            {
                case DbObjectTypes.Category:
                    result = this.getCategoryByTableId(id.ElementId, readAll);
                    break;
                case DbObjectTypes.Container:
                    result = this.getContainerByTableId(id.ElementId, readAll);
                    break;
                case DbObjectTypes.Item:
                    result = this.getItemByTableId(id.ElementId, readAll);
                    break;
                default:
                    throw new Exception("Неправильный тип элемента");
            }
            return result;
        }

        ///// <summary>
        ///// NT - удалить из таблиц БД все неактивные элементы, вернуть число удаленных элементов
        ///// </summary>
        //public int DeleteInactiveElements()
        //{
        //    //создать команду
        //    OleDbCommand cmd = new OleDbCommand("", this.m_connection, m_transaction);
        //    cmd.CommandTimeout = 600;

        //    int count = 0; //deleted items count

        //    //удалить неактивные записи из таблиц
        //    //DELETE FROM Items WHERE (deleted = True)
        //    cmd.CommandText = "DELETE FROM Items WHERE (deleted = True);";
        //    count = count + cmd.ExecuteNonQuery();

        //    //DELETE FROM Cats WHERE (deleted = True)
        //    cmd.CommandText = "DELETE FROM Cats WHERE (deleted = True);";
        //    count += cmd.ExecuteNonQuery();

        //    //DELETE FROM Sites WHERE (deleted = True)
        //    cmd.CommandText = "DELETE FROM Conts WHERE (deleted = True);";
        //    count += cmd.ExecuteNonQuery();

        //    return count;
        //}

        /// <summary>
        /// NT - удалить из таблиц БД все неактивные элементы, вернуть число удаленных предметов
        /// </summary>
        /// <returns>Возвращает число удаленных предметов, без категорий и контейнеров</returns>
        public int DeleteInactiveElements2()
        {
            //рекурсивно удалить все неактивные категории и контейнеры, не содержащие активных элементов 
            int count = 0;
            //сначала удалить все неактивные предметы - для них не нужна рекурсия
            count = this.DeleteAllInactiveItems();
            //теперь рекурсивно или итеративно пройти категории, начиная с корневой.
            //если категория неактивна, но содержит активные итемы, ее не удалять
            //если категория неактивна, но содержит неактивные или активные категории, ее не удалять.
            recursiveDeleteCategory(this.RootCategory.ObjectId.ElementId);//корневая категория не будет удалена, но это и не нужно

            recursiveDeleteContainer(this.RootContainer.ObjectId.ElementId);//корневая категория не будет удалена, но это и не нужно

            return count; //возвращаем число удаленных итемов, без категорий и контейнеров
        }
        /// <summary>
        /// NT-рекурсивно удалить пустые неактивные категории
        /// </summary>
        /// <param name="p">Идентификатор родительской категории</param>
        private bool recursiveDeleteCategory(int id)
        {
            //получить список элементов категории
            List<CCategory> categories = this.getCategoriesByParentId(id, false);
            //нельзя удалять категории из списка в цикле чтения списка
            //но нам лишь нужно количество оставшихся категорий, поэтому мы считаем это
            int categoryCount = categories.Count;
            //для каждой категории запустить рекурсию
            foreach (CCategory cat in categories)
            {
                int catid = cat.ObjectId.ElementId;
                bool res = recursiveDeleteCategory(catid);
                //если функция вернула True, удалить неактивную категорию из БД и из списка
                if ((res == true) && (cat.Deleted == true))
                {
                    categoryCount--; //уменьшаем счетчик категорий
                    this.DeleteCategoryById(catid);
                }
            }
            
            //если в списке есть активные итемы (неактивные должны быть уже удалены ранее),
            //активные или неактивные категории - в общем, если хоть что-то есть,
            //то вернуть False, чтобы не удалять эту категорию
            //иначе вернуть True
            if (categoryCount > 0) return false; //есть дочерние категории, не удалять текущую категорию
            categoryCount = this.getCountOfItemsByParentId(id, -1);
            if (categoryCount > 0) return false; //есть итемы, не удалять текущую категорию
            return true; //пустая категория
        }

        /// <summary>
        /// NT-рекурсивно удалить пустые неактивные контейнеры
        /// </summary>
        /// <param name="p">Идентификатор родительской контейнера</param>
        private bool recursiveDeleteContainer(int id)
        {
            //получить список элементов контейнер
            List<CContainer> containers = this.getContainersByParentId(id, false);
            //нельзя удалять контейнер из списка в цикле чтения списка
            //но нам лишь нужно количество оставшихся контейнер, поэтому мы считаем это
            int count = containers.Count;
            //для каждой контейнер запустить рекурсию
            foreach (CContainer cat in containers)
            {
                int catid = cat.ObjectId.ElementId;
                bool res = recursiveDeleteContainer(catid);
                //если функция вернула True, удалить неактивный контейнер из БД и из списка
                if ((res == true) && (cat.Deleted == true))
                {
                    count--; //уменьшаем счетчик контейнеров
                    this.DeleteContainerById(catid);
                }
            }

            //если в списке есть активные итемы (неактивные должны быть уже удалены ранее),
            //активные или неактивные контейнер - в общем, если хоть что-то есть,
            //то вернуть False, чтобы не удалять эту контейнер
            //иначе вернуть True
            if (count > 0) return false; //есть дочерние контейнер, не удалять текущую контейнер
            count = this.getCountOfItemsByParentId(-1, id);
            if (count > 0) return false; //есть итемы, не удалять текущую контейнер
            return true; //пустая контейнер
        }


        /// <summary>
        /// NT- delete element from table
        /// </summary>
        /// <param name="id">Element Id</param>
        /// <returns>Returns count of deleted elements</returns>
        private int DeleteCategoryById(int id)
        {
            //создать команду
            OleDbCommand cmd = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            int count = 0;

            //DELETE FROM Cats WHERE (id = id)
            cmd.CommandText = String.Format(CultureInfo.InvariantCulture, "DELETE FROM Cats WHERE (id = {0});", id);
            count = cmd.ExecuteNonQuery();
            return count;
        }
        /// <summary>
        /// NT- delete element from table
        /// </summary>
        /// <param name="id">Element Id</param>
        /// <returns>Returns count of deleted elements</returns>
        private int DeleteContainerById(int id)
        {
            //создать команду
            OleDbCommand cmd = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            int count = 0;

            //DELETE FROM Cats WHERE (id = id)
            cmd.CommandText = String.Format(CultureInfo.InvariantCulture, "DELETE FROM Conts WHERE (id = {0});", id);
            count = cmd.ExecuteNonQuery();
            return count;
        }


        /// <summary>
        /// NT- delete element from table
        /// </summary>
        /// <param name="id">Element Id</param>
        /// <returns>Returns count of deleted elements</returns>
        public int DeleteItemById(int id)
        {
            //создать команду
            OleDbCommand cmd = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            int count = 0;

            //DELETE FROM Cats WHERE (id = id)
            cmd.CommandText = String.Format(CultureInfo.InvariantCulture, "DELETE FROM Items WHERE (id = {0});", id);
            count = cmd.ExecuteNonQuery();
            return count;
        }

        /// <summary>
        /// NT- delete all inactive items from table
        /// </summary>
        /// <returns>Returns count of deleted elements</returns>
        private int DeleteAllInactiveItems()
        {
            //создать команду
            OleDbCommand cmd = new OleDbCommand(String.Empty, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            int count = 0;

            //DELETE FROM Cats WHERE (id = id)
            cmd.CommandText = "DELETE FROM Items WHERE (deleted = True);";
            count = cmd.ExecuteNonQuery();
            return count;
        }

        /// <summary>
        /// NT-Получить количество содержимого элемента
        /// </summary>
        /// <param name="obj">Объект элемента</param>
        /// <returns></returns>
        public int GetQuantityOfElement(CDbObject obj)
        {
            int result = 0;
            int id = obj.ObjectId.ElementId;
            switch (obj.ObjectId.ElementType)
            {
                case DbObjectTypes.Category:
                    result = this.getCountOfChildCategories(id);
                    result += this.getCountOfItemsByParentId(id, -1); 
                    break;
                case DbObjectTypes.Container:
                    result = this.getCountOfChildContainers(id);
                    result += this.getCountOfItemsByParentId(-1, id); 
                    break;
                case DbObjectTypes.Item:
                    result = (Int32)((CItem)obj).Quantity;
                    break;
                default:
                    throw new Exception("Неправильный тип объекта");
            }
            return result;
        }



        #endregion



        #region *** Search functions ***
        /// <summary>
        /// NT-собрать строку запроса для поиска элементов
        /// </summary>
        /// <param name="tablename"></param>
        /// <param name="pattern"></param>
        /// <param name="sf"></param>
        /// <returns></returns>
        private String makeSearchQuery(String tablename, String pattern, SearchFields sf)
        {
            //привести строку запроса из общепринятого к специфичному для БД виду
            //и удалить % с начала и конца, если они там есть
            String patternDb = pattern.Replace('*', '%');
            char[] trimchars = new char[] { '%' };
            patternDb = patternDb.TrimEnd(trimchars); 
            patternDb = patternDb.TrimStart(trimchars);

            StringBuilder sb = new StringBuilder(256);
            String pat = " LIKE '%" + patternDb + "%') OR ";
            sb.Append("SELECT * FROM ");
            sb.Append(tablename);
            sb.Append(" WHERE (");
            //check search flags
            if ((sf & SearchFields.Title) != 0) { sb.Append(" (title "); sb.Append(pat); }
            if ((sf & SearchFields.Webtitle) != 0) { sb.Append(" (shtitle "); sb.Append(pat); }
            if ((sf & SearchFields.Description) != 0) { sb.Append(" (descr "); sb.Append(pat); }
            if ((sf & SearchFields.Notes) != 0) { sb.Append(" (notes "); sb.Append(pat); }
            sb.Append("(0=1));");

            return sb.ToString();
        }

        /// <summary>
        /// NT-Поиск элементов по паттерну
        /// </summary>
        /// <param name="pattern">Паттерн для поиска</param>
        /// <param name="sf">Флаги полей, в которых искать</param>
        /// <param name="count">Лимит выборки</param>
        /// <returns>Список найденных элементов</returns>
        internal List<CDbObject> FindCategories(string pattern, SearchFields sf, int count)
        {

            //тут надо создать строку запроса с параметрами, причем число параметров должно соответствовать числу полей.
            //Это такой универсальный код для всех типов поиска, его надо как-то вынести в общую функцию.
            string query = this.makeSearchQuery("Cats", pattern, sf); //String.Format("SELECT * FROM Cats WHERE(title LIKE '{0}');", pattern);
            //create command
            OleDbCommand cmd = new OleDbCommand(query, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            ////execute command
            //read results
            OleDbDataReader rdr = cmd.ExecuteReader();
            List<CDbObject> li = new List<CDbObject>();
            //если флаг поля заметок указан, загружаем текст заметок
            bool readAll = ((sf & SearchFields.Notes) != 0);
            //читаем записи
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    CDbObject c = (CDbObject) ReadCategoryRow(rdr, readAll);
                    li.Add(c);
                    //limit output to specified "count" 
                    if (li.Count >= count) break;
                }
            }
            //close reader
            rdr.Close();
            return li;
        }
        /// <summary>
        /// NT-Поиск элементов по паттерну
        /// </summary>
        /// <param name="pattern">Паттерн для поиска</param>
        /// <param name="sf">Флаги полей, в которых искать</param>
        /// <param name="count">Лимит выборки</param>
        /// <returns>Список найденных элементов</returns>
        internal List<CDbObject> FindContainers(string pattern, SearchFields sf, int count)
        {
            //тут надо создать строку запроса с параметрами, причем число параметров должно соответствовать числу полей.
            //Это такой универсальный код для всех типов поиска, его надо как-то вынести в общую функцию.
            string query = this.makeSearchQuery("Conts", pattern, sf); 
            //create command
            OleDbCommand cmd = new OleDbCommand(query, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            ////execute command
            //read results
            OleDbDataReader rdr = cmd.ExecuteReader();
            List<CDbObject> li = new List<CDbObject>();
            //если флаг поля заметок указан, загружаем текст заметок
            bool readAll = ((sf & SearchFields.Notes) != 0);
            //читаем записи
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    CDbObject c = (CDbObject) ReadContainerRow(rdr, readAll);
                    li.Add(c);
                    //limit output to specified "count" 
                    if (li.Count >= count) break;
                }
            }
            //close reader
            rdr.Close();
            return li;
        }
        /// <summary>
        /// NT-Поиск элементов по паттерну
        /// </summary>
        /// <param name="pattern">Паттерн для поиска</param>
        /// <param name="sf">Флаги полей, в которых искать</param>
        /// <param name="count">Лимит выборки</param>
        /// <returns>Список найденных элементов</returns>
        internal List<CDbObject> FindItems(string pattern, SearchFields sf, int count)
        {
            //тут надо создать строку запроса с параметрами, причем число параметров должно соответствовать числу полей.
            //Это такой универсальный код для всех типов поиска, его надо как-то вынести в общую функцию.
            string query = this.makeSearchQuery("Items", pattern, sf);
            //create command
            OleDbCommand cmd = new OleDbCommand(query, this.m_connection, m_transaction);
            cmd.CommandTimeout = 600;
            ////execute command
            //read results
            OleDbDataReader rdr = cmd.ExecuteReader();
            List<CDbObject> li = new List<CDbObject>();
            //если флаг поля заметок указан, загружаем текст заметок
            bool readAll = ((sf & SearchFields.Notes) != 0);
            //читаем записи
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    CDbObject c = (CDbObject) ReadItemRow(rdr, readAll);
                    li.Add(c);
                    //limit output to specified "count" 
                    if (li.Count >= count) break;
                }
            }
            //close reader
            rdr.Close();
            return li;
        }
        #endregion

#region *** WebName functions ***
        /// <summary>
        /// NT-Создать незанятое веб-имя из названия элемента
        /// </summary>
        /// <param name="title">Название элемента как основа для веб-имени</param>
        /// <param name="parentTitle">Название родительского элемента, используется если название элемента непригодно.</param>
        /// <returns>Возвращает строку незанятого веб-имени.</returns>
        public String WebNameCreateFromTitle(string title, string parentTitle)
        {
            //копировал из Form1 а вообще лучше перенести все функции этих проверок в адаптер БД, так будет универсальнее.
            //сгенерировать веб-имя для категории
            String text = title;
            //если имя пустое, взять до 8 символов из имени родительской категории
            if (title.Length < 3)
            {
                text = parentTitle;
                if (text.Length > 8) text = text.Substring(0, 8);
            }

            String webname = CWebNameLink.createWebnameFromTitle(text);
            //проверить, что имя не занято, и если занято, то изменить
            //путем добавления в конец числа-счетчика попыток, обрезая имя так, чтобы оно не превышало максимума
            String wn = String.Copy(webname);
            Int32 counter = 0;
            while (this.IsDbContainsWebName(wn))
            {
                wn = String.Copy(webname);
                //получить строку счетчика
                string counterstring = counter.ToString(CultureInfo.InvariantCulture);
                //вычислить длину имени, чтобы поместилось в максимум вместе с текстом счетчика и разделителем
                Int32 len = 64 - (counterstring.Length + 1);
                //обрезать имя так, чтобы вошел счетчик и символ подчеркивания
                if (wn.Length > len)
                    wn = wn.Substring(0, len);
                //имя сформировать и потом проверить
                wn = wn + "_" + counterstring;
                counter++;//увеличить счетчик на следующий цикл
            }
            //тут wn должно содержать свободное веб-имя
            return wn;
        }

        /// <summary>
        /// NT-Проверка, что веб-имя соответствует правилам
        /// </summary>
        /// <param name="newname">Новое веб-имя элемента</param>
        /// <param name="oldname">Старое веб-имя элемента</param>
        /// <returns>true or false</returns>
        public bool WebNameCheck(string newname, string oldname)
        {
            //if oldname is valid and exists, and same as newname, return true
            if ((!CWebNameLink.IsInvalidWebName(oldname)) && (this.IsDbContainsWebName(oldname)) && (oldname.Equals(newname)))
                return true;
            //check newname
            if (CWebNameLink.IsInvalidWebName(newname)) return false;//длина от 3 до 64, не должно содержать неподходящих символов
            if (this.IsDbContainsWebName(newname)) return false; //должно быть уникальным в системе - это долгая операция, поэтому последняя
            else return true;
        }

#endregion


    }
}
